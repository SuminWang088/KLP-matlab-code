function f=frifunc(x)
  f=10*sin(pi*x(1)*x(2))+20*(x(3)-0.5)^2+10*x(4)+10*x(5);
end

