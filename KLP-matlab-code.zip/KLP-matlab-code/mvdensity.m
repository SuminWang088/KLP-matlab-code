function f_n = mvdensity(matrix,tempoint,H)
e=[];
[n,~]=size(matrix);
for j=1:n
    e(j)=exp(-sqrt((matrix(j,:)-tempoint)*H^(-1)*H^(-1)*(matrix(j,:)-tempoint)'));
end

f_n=sum(e)/(n*det(H));
end