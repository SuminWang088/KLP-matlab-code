
function tf = isfeasible(x, lb, ub)
    if ~isempty(lb) && any(x < lb)
        tf = false;
        return
    end
    if ~isempty(ub) && any(x > ub)
        tf = false;
        return
    end
    
    tf = true;
end