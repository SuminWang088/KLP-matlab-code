function [Mu, S, w] = gmparam_2c_p(p)
% [Mu, S, w] = gmparam_2c_p() returns the parameter values for a two-
% component bivariate Gaussian mixture distribution.
%
% Output:
% Mu - 2-by-2 matrix of mean vectors.
% S  - 2-by-2-by-2 array of covariance matrices.
% w  - 2-by-1 vector of weights.
%
% Date: January 11, 2018

    % d = 1.5;
    %p=5;
    Mu = zeros(2,p);
    S = repmat(eye(p), 1, 1, 2);
    w = [1; 0];
end
