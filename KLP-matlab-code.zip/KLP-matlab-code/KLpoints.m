function [X, e, nEval] = KLpoints(nDim, fpdf, fmin, nIter,hn)
%[X, e, nEval] =  klpointsnriid_greedy(nDim, fpdf, fmin, nIter) generates a point-
% set called Kullback-Leibler points (KL) using a one-point-at-a-time greedy
% for the  bivariate normal distribution N(0,I), where I is a 2*2
% identity matrix.
%
%%%%%%%%% Input:
% nDim  - number of dimensions of the target density.
% fpdf  - handle to the target density function.
% fmin  - handle to a nDim-dimensional minimiser.
% nIter - the number of KL points.
% hn is the coefficient of bandwidth. Based on our numerical experience, we
% recommend the empirical bandwidth h=hn*n^(-1/(nDim+4)), where
% hn=(4/(nDim+2))^(1/(nDim+4))*(sigma_{1}^{2}+..+sigma_{nDim}^{2})/nDim,
% sigma_{i}^{2} is the marginal variance for the i-th dimension of the
% distribution function.

%%%%%%Output:
% X     - nIter-by-nDim matrix of generated points.
% e     - the target function used to minimize at each iteration.
% nEval - number of density evaluations at each iteration.



    X = zeros(nIter, nDim);
    y = zeros(nIter, 1);
    e = zeros(nIter, 1);
    nEval = zeros(nIter, 1);

    % Generate x_1
    f = @(XNew)fq(XNew, fpdf);
    [X(1, :), y(1), e(1), nEval(1)] = fmin(f, double.empty(0, nDim));
    fprintf('n = 1\n');

    % Generate the rest
    for n = 2:nIter
        f = @(XNew)fe(XNew, fpdf, X, hn, n);
        [X(n, :), y(n), e(n), nEval(n)] = fmin(f, X(1:(n - 1), :));
        fprintf('n = %d\n', n);
    end
end

function [e, yNew] = fe(XNew, fpdf, X, hn,n)


[~, nDim] = size(XNew);
    yNew = fpdf(XNew);
    exist=X(1:(n - 1), :);
    matrix=[XNew;exist];
h=n^(-1/(nDim+4))*hn; %% h is the bandwidth; 
H=eye(nDim).*h;

log_ker_m=zeros(n,1);
for i=1:n
tempoint=matrix(i,:);
exist=matrix([1:i-1 i+1:n],:);
log_ker_m(i)=log(mvdensity(exist, tempoint,H));
end

sum_log_ker=sum(log_ker_m);
sum_log_ker=sum(log_ker_m);
ce=sum_log_ker-log(yNew);

kl=ce/n;
e=kl;


end

function [q, yNew] = fq(XNew, fpdf)
    yNew = fpdf(XNew);
    q = 1 ./ yNew;
end


