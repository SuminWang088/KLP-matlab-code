function f = Exp(x)
p=length(x);
f=exp(-x*ones(1,p)');
end