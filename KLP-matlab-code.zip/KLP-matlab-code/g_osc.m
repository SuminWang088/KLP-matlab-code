function g_osc =g_osc(x,d) 
g_osc=exp((-5/d)*x*x')*cos((-5/d)*ones(1,d)*x');
%g_osc=cos((-5/d)*ones(1,d)*x');
end