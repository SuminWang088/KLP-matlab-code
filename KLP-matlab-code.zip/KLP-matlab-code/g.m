function g1=g(x)
g1=exp(-sum(x)/45)-sin(x(4)+x(3)); %%d=4;
%g1=exp(-sum(x)/45); %%d=6;
end



