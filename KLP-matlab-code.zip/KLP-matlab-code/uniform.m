function f = uniform(x)
p=length(x);
c=0;
for i=1:p
    if x(i)>=0&&x(i)<=1
        c=c+1;
    else
      
    end
end

if c==p
    f=1;
else 
    f=0;
end
end